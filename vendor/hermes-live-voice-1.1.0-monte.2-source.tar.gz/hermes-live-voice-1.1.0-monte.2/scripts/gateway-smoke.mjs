import { spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
import { once } from "node:events";
import { mkdtempSync, rmSync } from "node:fs";
import { createServer } from "node:http";
import { tmpdir } from "node:os";
import { join } from "node:path";
import WebSocket from "ws";

const options = parseOptions(process.argv.slice(2));
const liveProvider = options.liveProvider;
const prompt = liveProvider === "local"
  ? 'Use start_background_task now. Set its message exactly to "local gateway integration check" and do not answer directly.'
  : "hello from gateway smoke";
const expectedTaskInput = liveProvider === "local" ? "local gateway integration check" : prompt;
const expectedOutput = "gateway smoke ok";
const runId = "run_gateway_smoke";
const dockerImage = options.dockerImage;
const dockerContainerName = dockerImage
  ? `hermes-live-gateway-smoke-${process.pid}-${randomUUID().slice(0, 8)}`
  : undefined;
const stateDirectory = mkdtempSync(join(tmpdir(), "hermes-live-gateway-smoke-"));
const observed = {
  capabilities: false,
  modelOptions: false,
  createSession: false,
  events: false,
  startRun: false,
  sessionKey: "",
  startRunBody: undefined,
  hermesError: undefined,
};
let releaseLocalRunCompletion = () => undefined;
const localRunCompletion = new Promise((resolve) => {
  releaseLocalRunCompletion = resolve;
});

const hermesServer = createServer((req, res) => {
  void handleHermesRequest(req, res).catch((error) => {
    observed.hermesError = error instanceof Error ? error : new Error(String(error));
    writeJson(res, 500, { error: observed.hermesError.message });
  });
});

await listen(hermesServer, 0, dockerImage ? "0.0.0.0" : "127.0.0.1");
const hermesPort = portOf(hermesServer);
const gatewayPort = await reservePort();
const gatewayEnvironment = {
  HERMES_BASE_URL: dockerImage
    ? `http://host.docker.internal:${hermesPort}`
    : `http://127.0.0.1:${hermesPort}`,
  HERMES_AGENT_API_SERVER_KEY: "hermes-smoke-secret",
  HERMES_LIVE_ALLOW_UNAUTHENTICATED: dockerImage ? "true" : "false",
  HERMES_LIVE_ALLOW_ORIGIN: "",
  HERMES_LIVE_AUTH_TOKEN: "",
  HERMES_LIVE_HERMES_TIMEOUT_MS: "5000",
  HERMES_LIVE_HOST: dockerImage ? "0.0.0.0" : "127.0.0.1",
  HERMES_LIVE_MAX_TEXT_CHARS: "20000",
  HERMES_LIVE_PROFILE_ID: "default",
  HERMES_LIVE_USER_LABEL: "voice",
  HERMES_LIVE_TRUST_CLIENT_IDENTITY: "false",
  HERMES_LIVE_PORT: dockerImage ? "8788" : String(gatewayPort),
  HERMES_LIVE_PROVIDER: liveProvider,
  HERMES_LIVE_LOCAL_URL: "ws://127.0.0.1:8765/v1/realtime",
  HERMES_LIVE_PROVIDER_READY_TIMEOUT_MS: liveProvider === "local" ? "30000" : "5000",
  HERMES_LIVE_SESSION_PREFIX: "agent:main:hermes-live",
  HERMES_LIVE_TASK_POLL_INTERVAL_MS: "250",
  HERMES_LIVE_TASK_STATE_FILE: dockerImage
    ? "/var/lib/hermes-live/tasks-v1.json"
    : join(stateDirectory, "tasks-v1.json"),
  HERMES_LIVE_LOG_LEVEL: "warn",
  NODE_ENV: "test",
  PORT: dockerImage ? "8788" : String(gatewayPort),
};
const gateway = dockerImage
  ? spawn(
    "docker",
    [
      "run",
      "--rm",
      "--init",
      "--pull",
      "never",
      "--name",
      dockerContainerName,
      "--add-host",
      "host.docker.internal:host-gateway",
      "--read-only",
      "--cap-drop",
      "ALL",
      "--security-opt",
      "no-new-privileges=true",
      "--publish",
      `127.0.0.1:${gatewayPort}:8788`,
      "--tmpfs",
      "/var/lib/hermes-live:rw,noexec,nosuid,nodev,mode=0700,uid=1000,gid=1000",
      ...Object.entries(gatewayEnvironment).flatMap(([key, value]) => ["--env", `${key}=${value}`]),
      dockerImage,
    ],
    { stdio: ["ignore", "pipe", "pipe"] },
  )
  : spawn(process.execPath, ["dist/cli.js", "serve"], {
    env: { ...process.env, ...gatewayEnvironment },
    stdio: ["ignore", "pipe", "pipe"],
  });

let stdout = "";
let stderr = "";
let gatewayExited = false;
gateway.stdout.on("data", (chunk) => {
  stdout = appendBounded(stdout, chunk.toString("utf8"));
});
gateway.stderr.on("data", (chunk) => {
  stderr = appendBounded(stderr, chunk.toString("utf8"));
});
const gatewayExit = once(gateway, "exit").then(([code, signal]) => {
  gatewayExited = true;
  return { code, signal };
});

try {
  const readiness = await waitForReadiness(
    `http://127.0.0.1:${gatewayPort}/ready`,
    liveProvider === "local" ? 30_000 : 6_000,
  );
  if (readiness.status !== "ready") {
    throw new Error(`Gateway readiness status mismatch: ${JSON.stringify(readiness)}.`);
  }
  if (
    readiness.checks?.gateway?.ok !== true
    || readiness.checks?.hermes?.ok !== true
    || readiness.checks?.realtime?.ok !== true
    || readiness.checks?.tasks?.ok !== true
  ) {
    throw new Error(`Gateway readiness checks were not all ok: ${JSON.stringify(readiness)}.`);
  }
  const expectedModel = liveProvider === "local" ? "huggingface/speech-to-speech" : "mock-live";
  if (readiness.checks?.realtime?.provider !== liveProvider || readiness.checks?.realtime?.model !== expectedModel) {
    throw new Error(`Gateway readiness advertised unexpected realtime provider: ${JSON.stringify(readiness.checks?.realtime)}.`);
  }
  if (readiness.checks?.realtime?.sessionChecked !== false) {
    throw new Error(`Gateway readiness should disclose that provider sessions are not opened by /ready: ${JSON.stringify(readiness.checks?.realtime)}.`);
  }

  const healthResponse = await fetch(`http://127.0.0.1:${gatewayPort}/health`);
  const health = await healthResponse.json();
  if (!healthResponse.ok || health.status !== "ok" || health.service !== "hermes-live") {
    throw new Error(`Gateway health response mismatch: HTTP ${healthResponse.status} ${JSON.stringify(health)}.`);
  }

  const socket = new WebSocket(`ws://127.0.0.1:${gatewayPort}/v1/live`, {
    headers: { origin: `http://127.0.0.1:${gatewayPort}` },
  });
  const inbox = createInbox(socket);
  await waitForOpen(socket, 5_000);

  socket.send(JSON.stringify({
    type: "session.start",
    protocolVersion: 6,
    profileId: "smoke",
    userLabel: "gateway-smoke",
    conversation: { mode: "new", title: "Gateway smoke" },
  }));
  const providerTimeoutMs = liveProvider === "local" ? 90_000 : 5_000;
  const ready = await inbox.next("session.ready", providerTimeoutMs);
  if (ready.model !== expectedModel) {
    throw new Error(`Gateway session advertised unexpected model: ${JSON.stringify(ready.model)}.`);
  }
  if (
    ready.protocolVersion !== 6
    || ready.conversation?.sessionId !== "session_gateway_smoke"
    || ready.tasks?.durable !== true
    || ready.tasks?.supports?.followUp !== true
    || ready.tasks?.reconnect !== "snapshot"
  ) {
    throw new Error(`Gateway session did not advertise the protocol-v6 conversation/task contract: ${JSON.stringify(ready)}.`);
  }
  const initial = await inbox.next("task.snapshot");
  if (initial.reason !== "initial" || initial.tasks.length !== 0 || initial.truncated !== false) {
    throw new Error(`Gateway emitted an unexpected initial task snapshot: ${JSON.stringify(initial)}.`);
  }

  socket.send(JSON.stringify({ type: "text.input", text: prompt }));
  const accepted = await inbox.next("task.accepted", providerTimeoutMs);
  if (!/^task_[0-9a-f]{32}$/u.test(accepted.taskId)) {
    throw new Error(`Gateway emitted an invalid stable task id: ${JSON.stringify(accepted.taskId)}.`);
  }
  if (liveProvider === "local") {
    // Prove the full local tool loop, not only model-selected delegation. Keep
    // the fake Hermes run open until Qwen consumes the durable receipt, emits
    // a concise user-facing acknowledgement, and TTS begins speaking it.
    const [spoken, audio] = await Promise.all([
      inbox.next("transcript.delta", providerTimeoutMs),
      inbox.next("audio.output", providerTimeoutMs),
    ]);
    if (spoken.speaker !== "assistant" || spoken.final !== true) {
      throw new Error(`Local voice did not emit a final assistant receipt: ${JSON.stringify(spoken)}.`);
    }
    if (spoken.text?.trim() !== "I've started that in the background. You can keep talking.") {
      throw new Error(`Local voice spoke an unsafe or overly long task receipt: ${JSON.stringify(spoken.text)}.`);
    }
    if (!audio.data || !audio.mimeType?.startsWith("audio/pcm")) {
      throw new Error(`Local voice did not synthesize PCM receipt audio: ${JSON.stringify(audio)}.`);
    }
    releaseLocalRunCompletion();
  }
  const completed = await inbox.next("task.completed", providerTimeoutMs);
  if (completed.taskId !== accepted.taskId || completed.result?.output !== expectedOutput) {
    throw new Error(`Gateway task output mismatch. Expected ${JSON.stringify(expectedOutput)}, got ${JSON.stringify(completed)}.`);
  }

  socket.close(1000, "gateway smoke complete");
  await waitForSocketClose(socket, 2_000);

  if (!observed.capabilities) {
    throw new Error("Gateway did not call Hermes /v1/capabilities.");
  }
  if (!observed.modelOptions) {
    throw new Error("Gateway did not resolve Hermes' configured model.");
  }
  if (!observed.createSession) {
    throw new Error("Gateway did not create the selected Hermes conversation.");
  }
  if (!observed.startRun) {
    throw new Error("Gateway did not start a Hermes run.");
  }
  if (!observed.events) {
    throw new Error("Gateway did not consume Hermes run events.");
  }
  if (observed.hermesError) {
    throw observed.hermesError;
  }

  console.log(`Gateway smoke ok (${dockerImage ? "Docker image" : `${liveProvider} provider`})`);
} finally {
  releaseLocalRunCompletion();
  if (dockerContainerName) {
    await removeDockerContainer(dockerContainerName);
  }
  await stopChild(gateway, gatewayExit, () => gatewayExited);
  await closeServer(hermesServer);
  rmSync(stateDirectory, { recursive: true, force: true });
}

function parseOptions(args) {
  let dockerImage;
  let liveProvider = "mock";
  for (let index = 0; index < args.length; index += 1) {
    const argument = args[index];
    if (argument === "--docker-image") {
      dockerImage = args[index + 1];
      if (!dockerImage?.trim()) throw new Error("--docker-image requires an image name.");
      index += 1;
    } else if (argument === "--live-provider") {
      liveProvider = args[index + 1];
      if (!["mock", "local"].includes(liveProvider)) throw new Error("--live-provider must be mock or local.");
      index += 1;
    } else {
      throw new Error("Usage: node scripts/gateway-smoke.mjs [--docker-image <image>] [--live-provider <mock|local>]");
    }
  }
  if (dockerImage && liveProvider !== "mock") {
    throw new Error("The Docker smoke uses the self-contained mock provider.");
  }
  return { dockerImage, liveProvider };
}

async function handleHermesRequest(req, res) {
  const url = new URL(req.url ?? "/", "http://127.0.0.1");
  if (req.method === "GET" && url.pathname === "/v1/capabilities") {
    observed.capabilities = true;
    writeJson(res, 200, {
      object: "hermes.capabilities",
      model: "hermes-agent",
      features: {
        run_submission: true,
        run_status: true,
        run_events_sse: true,
        run_stop: true,
        run_approval_response: true,
        session_resources: true,
        session_chat: true,
        session_chat_streaming: true,
        model_options: true,
        session_model_lock: true,
      },
    });
    return;
  }

  if (req.method === "GET" && url.pathname === "/api/model/options") {
    observed.modelOptions = true;
    writeJson(res, 200, { model: "gpt-5.4-mini", provider: "openai-api", providers: [] });
    return;
  }

  if (req.method === "POST" && url.pathname === "/api/sessions") {
    const body = await readJson(req);
    observed.createSession = true;
    if (
      body.model !== "gpt-5.4-mini"
      || body.provider !== "openai-api"
      || body.title !== "Gateway smoke"
    ) {
      throw new Error(`Unexpected Hermes session creation body: ${JSON.stringify(body)}.`);
    }
    writeJson(res, 201, {
      object: "hermes.session",
      session: { id: "session_gateway_smoke", title: "Gateway smoke", model: "gpt-5.4-mini" },
    });
    return;
  }

  if (req.method === "POST" && url.pathname === "/v1/runs") {
    const body = await readJson(req);
    const sessionKey = String(req.headers["x-hermes-session-key"] ?? "");
    const authorization = String(req.headers.authorization ?? "");
    observed.startRun = true;
    observed.sessionKey = sessionKey;
    observed.startRunBody = body;

    if (authorization !== "Bearer hermes-smoke-secret") {
      throw new Error(`Unexpected Hermes authorization header: ${JSON.stringify(authorization)}.`);
    }
    if (!sessionKey.includes("agent:main:hermes-live:profile:default:user:voice")) {
      throw new Error(`Unexpected Hermes session key: ${JSON.stringify(sessionKey)}.`);
    }
    if (Object.hasOwn(body, "model")) {
      throw new Error(`Hermes should choose the configured task model: ${JSON.stringify(body.model)}.`);
    }
    if (body.input !== expectedTaskInput) {
      throw new Error(`Unexpected Hermes input: ${JSON.stringify(body.input)}.`);
    }
    if (typeof body.session_id !== "string" || !/^hermes-live:task:task_[0-9a-f]{32}$/u.test(body.session_id)) {
      throw new Error(`Unexpected Hermes session_id: ${JSON.stringify(body.session_id)}.`);
    }

    writeJson(res, 202, { run_id: runId, status: "started" });
    return;
  }

  if (req.method === "GET" && url.pathname === `/v1/runs/${runId}`) {
    writeJson(res, 200, {
      object: "hermes.run",
      run_id: runId,
      status: "running",
    });
    return;
  }

  if (req.method === "GET" && url.pathname === `/v1/runs/${runId}/events`) {
    const sessionKey = String(req.headers["x-hermes-session-key"] ?? "");
    const authorization = String(req.headers.authorization ?? "");
    observed.events = true;
    if (authorization !== "Bearer hermes-smoke-secret") {
      throw new Error(`Unexpected Hermes events authorization header: ${JSON.stringify(authorization)}.`);
    }
    if (sessionKey !== observed.sessionKey) {
      throw new Error(`Unexpected Hermes events session key: ${JSON.stringify(sessionKey)}.`);
    }
    res.writeHead(200, {
      "content-type": "text/event-stream; charset=utf-8",
      "cache-control": "no-cache",
      connection: "close",
    });
    // A real SSE endpoint commits headers before a long-running task emits its
    // first event. Without this, Node may buffer the headers and make the
    // client's request deadline look like a task failure during the local
    // model's spoken acknowledgement.
    res.flushHeaders();
    if (liveProvider === "local") await localRunCompletion;
    res.write('event: message.delta\ndata: {"event":"message.delta","run_id":"run_gateway_smoke","delta":"gateway smoke ok"}\n\n');
    res.end('event: run.completed\ndata: {"event":"run.completed","run_id":"run_gateway_smoke","output":"gateway smoke ok","usage":{"input_tokens":10,"output_tokens":3,"total_tokens":13}}\n\n');
    return;
  }

  if (req.method === "POST" && url.pathname === `/v1/runs/${runId}/stop`) {
    writeJson(res, 200, { run_id: runId, status: "stopping" });
    return;
  }

  writeJson(res, 404, { error: `Unhandled fake Hermes route: ${req.method} ${url.pathname}` });
}

async function readJson(req) {
  let raw = "";
  for await (const chunk of req) {
    raw += chunk.toString("utf8");
  }
  return raw ? JSON.parse(raw) : {};
}

function writeJson(res, status, body) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "content-length": String(Buffer.byteLength(payload)),
  });
  res.end(payload);
}

function createInbox(socket) {
  const queued = [];
  let pending = [];

  socket.on("message", (raw) => {
    const message = JSON.parse(raw.toString("utf8"));
    if (["session.error", "task.failed", "task.unknown"].includes(message.type)) {
      const error = new Error(`Gateway emitted ${message.type}: ${message.message ?? message.error ?? JSON.stringify(message)}`);
      const waiters = pending;
      pending = [];
      for (const waiter of waiters) {
        clearTimeout(waiter.timer);
        waiter.reject(error);
      }
      queued.push(message);
      return;
    }

    const index = pending.findIndex((waiter) => waiter.type === message.type);
    if (index >= 0) {
      const [waiter] = pending.splice(index, 1);
      clearTimeout(waiter.timer);
      waiter.resolve(message);
      return;
    }
    queued.push(message);
  });

  socket.on("close", (code, reason) => {
    const error = new Error(`Gateway WebSocket closed before expected message: ${code} ${reason.toString("utf8")}`);
    const waiters = pending;
    pending = [];
    for (const waiter of waiters) {
      clearTimeout(waiter.timer);
      waiter.reject(error);
    }
  });

  socket.on("error", (error) => {
    const waiters = pending;
    pending = [];
    for (const waiter of waiters) {
      clearTimeout(waiter.timer);
      waiter.reject(error);
    }
  });

  return {
    next(type, timeoutMs = 5_000) {
      const index = queued.findIndex((message) => message.type === type);
      if (index >= 0) {
        const [message] = queued.splice(index, 1);
        return Promise.resolve(message);
      }
      const terminal = queued.find((message) => ["session.error", "task.failed", "task.unknown"].includes(message.type));
      if (terminal) {
        return Promise.reject(new Error(`Gateway emitted ${terminal.type}: ${terminal.message ?? terminal.error ?? JSON.stringify(terminal)}`));
      }
      return new Promise((resolve, reject) => {
        const waiter = {
          type,
          resolve,
          reject,
          timer: setTimeout(() => {
            pending = pending.filter((candidate) => candidate !== waiter);
            reject(new Error(`Timed out waiting for gateway message ${type}. Queued: ${queuedMessageSummary(queued)}`));
          }, timeoutMs),
        };
        pending.push(waiter);
      });
    },
  };
}

function queuedMessageSummary(messages) {
  const counts = new Map();
  for (const message of messages) {
    counts.set(message.type, (counts.get(message.type) ?? 0) + 1);
  }
  return JSON.stringify(Object.fromEntries(counts));
}

async function waitForReadiness(url, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  let lastError;
  while (Date.now() < deadline) {
    if (gatewayExited) {
      const exit = await gatewayExit;
      throw new Error(`Gateway exited before readiness: ${exit.code ?? "null"} ${exit.signal ?? "null"}\n${stdout}\n${stderr}`);
    }
    try {
      const response = await fetch(url);
      const body = await response.text();
      if (response.ok) {
        return JSON.parse(body);
      }
      lastError = new Error(`HTTP ${response.status}: ${body}`);
    } catch (error) {
      lastError = error;
    }
    await delay(100);
  }
  throw new Error(`Timed out waiting for ${url}. Last error: ${String(lastError)}\n${stdout}\n${stderr}`);
}

async function waitForOpen(socket, timeoutMs) {
  if (socket.readyState === WebSocket.OPEN) {
    return;
  }
  await promiseWithTimeout(once(socket, "open"), timeoutMs, "Timed out waiting for gateway WebSocket open.");
}

async function waitForSocketClose(socket, timeoutMs) {
  if (socket.readyState === WebSocket.CLOSED) {
    return;
  }
  await promiseWithTimeout(once(socket, "close"), timeoutMs, "Timed out waiting for gateway WebSocket close.");
}

async function reservePort() {
  const server = createServer();
  await listen(server, 0, "127.0.0.1");
  const port = portOf(server);
  await closeServer(server);
  return port;
}

function listen(server, port, host) {
  return new Promise((resolve, reject) => {
    const cleanup = () => {
      server.off("error", onError);
      server.off("listening", onListening);
    };
    const onError = (error) => {
      cleanup();
      reject(error);
    };
    const onListening = () => {
      cleanup();
      resolve();
    };
    server.once("error", onError);
    server.once("listening", onListening);
    server.listen(port, host);
  });
}

function portOf(server) {
  const address = server.address();
  if (!address || typeof address !== "object") {
    throw new Error("Server did not expose a TCP port.");
  }
  return address.port;
}

function closeServer(server) {
  return new Promise((resolve, reject) => {
    server.close((error) => (error ? reject(error) : resolve()));
  });
}

async function stopChild(child, exitPromise, hasExited) {
  if (!hasExited()) {
    child.kill("SIGTERM");
    const stopped = await Promise.race([
      exitPromise.then(() => true),
      delay(2_000).then(() => false),
    ]);
    if (!stopped && !hasExited()) {
      child.kill("SIGKILL");
      await exitPromise.catch(() => undefined);
    }
  }
}

async function removeDockerContainer(name) {
  const child = spawn("docker", ["rm", "--force", name], { stdio: "ignore" });
  await once(child, "exit").catch(() => undefined);
}

function appendBounded(current, next, max = 20_000) {
  const combined = current + next;
  return combined.length > max ? combined.slice(combined.length - max) : combined;
}

async function promiseWithTimeout(promise, timeoutMs, message) {
  let timer;
  try {
    await Promise.race([
      promise,
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error(message)), timeoutMs);
      }),
    ]);
  } finally {
    clearTimeout(timer);
  }
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
