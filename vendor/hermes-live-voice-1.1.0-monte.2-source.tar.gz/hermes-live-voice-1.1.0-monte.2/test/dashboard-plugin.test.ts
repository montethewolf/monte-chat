import { readFileSync } from "node:fs";
import vm from "node:vm";
import { describe, expect, it, vi } from "vitest";

const dashboardUrl = new URL("../plugins/hermes-live/dashboard/", import.meta.url);

describe("Hermes Dashboard plugin", () => {
  it("registers the Live Voice tab synchronously as a dependency-free IIFE", () => {
    const register = vi.fn();
    const window = {
      __HERMES_PLUGINS__: { register },
      location: { href: "http://127.0.0.1:9119/live-voice" },
    };
    const document = dashboardDocument();
    const source = dashboardSource();

    vm.runInNewContext(source, { document, URL, window }, {
      filename: "plugins/hermes-live/dashboard/dist/index.js",
    });

    expect(register).toHaveBeenCalledTimes(1);
    expect(register).toHaveBeenCalledWith("hermes-live", expect.any(Function));
  });

  it("declares an official Dashboard tab, assets, and backend with package-version parity", () => {
    const manifest = JSON.parse(readFileSync(new URL("manifest.json", dashboardUrl), "utf8"));
    const packageJson = JSON.parse(readFileSync(new URL("../package.json", import.meta.url), "utf8"));

    expect(manifest).toMatchObject({
      name: "hermes-live",
      label: "Live Voice",
      icon: "Zap",
      version: packageJson.version,
      tab: { path: "/live-voice", position: "after:chat" },
      entry: "dist/index.js",
      css: "dist/style.css",
      api: "plugin_api.py",
    });
  });

  it("uses only host-authenticated Dashboard APIs and contains no static secret hooks", () => {
    const source = dashboardSource();

    expect(source).toContain("SDK.buildWsUrl(LIVE_ENDPOINT)");
    expect(source).toContain("SDK.fetchJSON(STATUS_ENDPOINT)");
    expect(source).toContain("SDK.fetchJSON(CONVERSATIONS_ENDPOINT)");
    expect(source).not.toContain("__HERMES_SESSION_TOKEN__");
    expect(source).not.toContain("HERMES_LIVE_AUTH_TOKEN");
    expect(source).not.toContain("OPENAI_API_KEY");
    expect(source).not.toContain("GEMINI_API_KEY");
  });

  it("offers a no-code saved-chat picker and binds the selected session", () => {
    const source = dashboardSource();

    expect(source).toContain("Start a new chat");
    expect(source).toContain("Continue a saved chat or start a fresh one.");
    expect(source).toContain('? { mode: "new" }');
    expect(source).not.toContain('{ mode: "new", title: "Live Voice" }');
    expect(source).toContain('{ mode: "resume", sessionId: conversationId }');
    expect(source).toContain("if (attachedSessionId) setConversationId(attachedSessionId);");
    expect(source).toContain("client.connect({ conversation: conversation })");
  });

  it("presents durable multi-task work without legacy singleton controls", () => {
    const source = dashboardSource();
    const forbidden = [
      ["stop", "Run"],
      ["active", "Run"],
      ["run", "Id"],
      ["respond", "ToAppro", "val"],
      ["waiting_for_appro", "val"],
    ].map((parts) => parts.join(""));

    expect(source).toContain("Keep talking while Hermes keeps working.");
    expect(source).toContain("Continuous voice for saved chats, durable tasks, and live progress.");
    expect(source).toContain("Task inbox");
    expect(source).toContain("Stable task ID");
    expect(source).toContain('client.stopTask(task.taskId, "stopped from Hermes Dashboard")');
    expect(source).toContain("client.acknowledgeNotification(notification.taskId, notification.notificationId)");
    expect(source).toContain("leaving this page does not cancel background work");
    expect(source).toContain('className: "hlv-task-item"');
    for (const token of forbidden) expect(source).not.toContain(token);
  });

  it("keeps speech interruption independent from exact task stopping", () => {
    const source = dashboardSource();

    expect(source).toContain('audio.interrupt("interrupted from Hermes Dashboard")');
    expect(source).toContain('audio.interrupt("provider detected user speech")');
    expect(source).toContain('audio.interrupt("new Dashboard text input")');
    expect(source).toContain("Assistant speech interrupted. Background tasks keep running.");
    expect(source).toContain("Interrupt speech");
    expect(source).toContain("Stop task");
    expect(source).toContain('client.on("input.pause_requested"');
    expect(source).toContain('text: "Listening paused by voice command. Press Start microphone when you want to resume."');
    expect(source).toContain("audio.stopMicrophone({ endTurn: false })");
    expect(source).toContain("audio.clearPlayback()");
    expect(source).toContain("audio.primePlayback()");
    expect(source).toContain("const audio = primePlaybackFromGesture();");
  });

  it("keeps stable task identity and attaches unread updates under out-of-order completion", () => {
    const utilities = loadDashboardUtilities();
    const activeSecond = task("task_second", "running", 8, 2_000);
    const activeFirst = task("task_first", "queued", 3, 1_000);
    const finishedThird = task("task_third", "completed", 11, 3_000, { result: { summary: "done" } });
    const notification = {
      taskId: "task_third",
      notificationId: "note_third",
      message: "Third task finished first.",
    };

    const items = utilities.taskInboxItems({
      activeTasks: [activeSecond, activeFirst],
      recentTasks: [finishedThird],
      unreadNotifications: [notification],
    });

    expect(items.map((item: any) => item.task.taskId)).toEqual(["task_second", "task_first", "task_third"]);
    expect(items[0].notification).toBeUndefined();
    expect(items[2]).toMatchObject({ task: { taskId: "task_third", sequence: 11 }, notification });
  });

  it("bounds the recent inbox while preserving every active task", () => {
    const utilities = loadDashboardUtilities();
    const active = Array.from({ length: 3 }, (_, index) => task(`active_${index}`, "running", index + 1, index));
    const recent = Array.from({ length: 30 }, (_, index) => task(`recent_${index}`, "completed", index + 1, index));

    const items = utilities.taskInboxItems({ activeTasks: active, recentTasks: recent, unreadNotifications: [] });

    expect(items).toHaveLength(19);
    expect(items.slice(0, 3).map((item: any) => item.task.taskId)).toEqual([
      "active_0",
      "active_1",
      "active_2",
    ]);
    expect(items.at(-1).task.taskId).toBe("recent_15");
  });

  it("keeps every unread task visible beyond the bounded recent window without duplicates", () => {
    const utilities = loadDashboardUtilities();
    const active = [task("active_task", "running", 1, 1)];
    const recent = Array.from({ length: 30 }, (_, index) =>
      task(`recent_${index}`, "completed", index + 2, 10_000 - index));
    const notification = {
      taskId: "recent_25",
      notificationId: "note_recent_25",
      message: "An older task still needs attention.",
    };

    const items = utilities.taskInboxItems({
      activeTasks: active,
      recentTasks: recent,
      unreadNotifications: [notification],
    });

    expect(items.map((item: any) => item.task.taskId)).toEqual([
      "active_task",
      "recent_25",
      ...Array.from({ length: 16 }, (_, index) => `recent_${index}`),
    ]);
    expect(items.filter((item: any) => item.task.taskId === "recent_25")).toHaveLength(1);
    expect(items[1]).toMatchObject({ notification });
    expect(utilities.taskInboxSummary({
      activeTasks: active,
      recentTasks: recent,
      unreadNotifications: [notification],
    })).toBe("1 active · 30 recent · 1 unread");
  });

  it("summarizes task state, progress, results, errors, and unread counts", () => {
    const utilities = loadDashboardUtilities();

    expect(utilities.taskStatePresentation("running")).toEqual({ label: "Running", tone: "active" });
    expect(utilities.taskStatePresentation("completed")).toEqual({ label: "Completed", tone: "success" });
    expect(utilities.taskStatePresentation("failed")).toEqual({ label: "Failed", tone: "danger" });
    expect(utilities.isTaskActive({ state: "unknown" })).toBe(false);
    expect(utilities.isTaskActive({ state: "completed" })).toBe(false);
    expect(utilities.taskProgressText({ message: "Reviewing", percent: 48.6 })).toBe("Reviewing · 49%");
    expect(utilities.taskProgressText({ message: "Files", current: 2, total: 5 })).toBe("Files · 2/5");
    expect(utilities.taskDetail({ result: { output: "full output", summary: "summary" } })).toBe("full output");
    expect(utilities.taskDetail({ error: { message: "failed safely" } })).toBe("failed safely");
    expect(utilities.taskInboxSummary({
      activeTasks: [task("one", "running", 1, 1)],
      recentTasks: [task("two", "completed", 2, 2)],
      unreadNotifications: [{ taskId: "two" }],
    })).toBe("1 active · 1 recent · 1 unread");
    expect(utilities.taskInboxSummary({ activeTasks: [], recentTasks: [], unreadNotifications: [] }))
      .toBe("No background tasks yet");
  });

  it("attempts protocol detach even when microphone cleanup fails", async () => {
    const utilities = loadDashboardUtilities();
    const audio = { stopMicrophone: vi.fn(async () => { throw new Error("capture cleanup failed"); }) };
    const client = { disconnect: vi.fn(async () => undefined) };
    const onAudioError = vi.fn();

    await expect(utilities.disconnectSession(audio, client, onAudioError)).resolves.toBeUndefined();
    expect(audio.stopMicrophone).toHaveBeenCalledWith({ endTurn: false });
    expect(client.disconnect).toHaveBeenCalledWith("user disconnected from dashboard");
    await vi.waitFor(() => expect(onAudioError).toHaveBeenCalledWith(expect.objectContaining({
      message: "capture cleanup failed",
    })));
  });

  it("does not wait for stalled microphone cleanup before detaching voice", async () => {
    const utilities = loadDashboardUtilities();
    const audio = { stopMicrophone: vi.fn(async () => await new Promise(() => undefined)) };
    const client = { disconnect: vi.fn(async () => undefined) };

    await expect(utilities.disconnectSession(audio, client)).resolves.toBeUndefined();
    expect(client.disconnect).toHaveBeenCalledOnce();
  });

  it("preserves the useful session error when a provider closure follows it", () => {
    const utilities = loadDashboardUtilities();
    const source = dashboardSource();
    const fatal = { tone: "danger", text: "The provider rejected this voice session." };

    expect(utilities.connectionClosedNotice({ clean: true }, fatal)).toMatchObject(fatal);
    expect(utilities.connectionClosedNotice({ clean: false }, null)).toMatchObject({
      tone: "warning",
      text: "Live Voice connection was lost. Reconnect to sync task updates.",
    });
    expect(utilities.connectionClosedNotice({ clean: true }, null).text)
      .toBe("Live Voice disconnected.");
    expect(source).toContain('client.on("response.started"');
    expect(source).toContain('event.detail && event.detail.type === "session.error"');
    expect(source).toContain('event.code === "connection_lost" && disconnectNoticeRef.current');
    expect(source).toContain("disconnectNoticeRef.current && disconnectNoticeRef.current.notice");
  });

  it("gives accurate microphone and text-only guidance from negotiated capabilities", () => {
    const utilities = loadDashboardUtilities();

    expect(utilities.microphoneActiveGuidance("disabled")).toContain("stop the microphone to submit");
    expect(utilities.microphoneActiveGuidance("semantic_vad")).toContain("Speak naturally");
    expect(utilities.connectedSessionNotice({ enabled: false }, false))
      .toBe("Live Voice is connected in text mode. Type a message to Hermes.");
    expect(utilities.connectedSessionGuidance(false)).toBe("Type a message below.");
    expect(utilities.connectedSessionNotice({ enabled: true }, true, true)).toContain("Connected and listening");
    expect(utilities.connectedSessionGuidance(true)).toContain("Start the microphone");
    expect(utilities.supportsBrowserPlayback({ enabled: false })).toBe(false);
    expect(utilities.supportsBrowserPlayback({ enabled: true, mimeType: "audio/pcm;rate=24000" })).toBe(true);
    expect(utilities.supportsBrowserPlayback({ enabled: true, mimeType: "audio/opus" })).toBe(false);
    expect(utilities.supportsBrowserMicrophone({ enabled: true, mimeType: "audio/pcm;rate=16000" })).toBe(true);
  });

  it("starts a compatible microphone automatically after one Connect click", async () => {
    const utilities = loadDashboardUtilities();
    const source = dashboardSource();
    const audio = { startMicrophone: vi.fn(async () => undefined) };

    await expect(utilities.startMicrophoneAfterConnect(audio, {
      enabled: true,
      mimeType: "audio/pcm;rate=16000",
    })).resolves.toEqual({ started: true });
    expect(audio.startMicrophone).toHaveBeenCalledOnce();

    await expect(utilities.startMicrophoneAfterConnect(audio, {
      enabled: false,
    })).resolves.toEqual({ started: false });
    expect(audio.startMicrophone).toHaveBeenCalledOnce();
    expect(source).toContain("void startMicrophoneAfterConnect(audio, connectedInputAudio, function () {");
    expect(source).not.toContain("client.connect({ conversation: conversation }).then(async function");
    expect(source).toContain("Live Voice connected. Allow microphone access to start talking.");
  });

  it("keeps the connection controls in view until a transcript actually exists", () => {
    const utilities = loadDashboardUtilities();
    const viewport = { scrollTop: 0, scrollHeight: 640 };

    utilities.scrollTranscriptToLatest(viewport, 0);
    expect(viewport.scrollTop).toBe(0);

    utilities.scrollTranscriptToLatest(viewport, 1);
    expect(viewport.scrollTop).toBe(640);
    expect(dashboardSource()).not.toContain("scrollIntoView");
  });

  it("stops a microphone permission result that arrives after disconnect", async () => {
    const utilities = loadDashboardUtilities();
    let finishPermission!: () => void;
    let current = true;
    const permission = new Promise<void>((resolve) => { finishPermission = resolve; });
    const audio = {
      startMicrophone: vi.fn(async () => await permission),
      stopMicrophone: vi.fn(async () => undefined),
    };
    const pending = utilities.startMicrophoneAfterConnect(
      audio,
      { enabled: true, mimeType: "audio/pcm;rate=16000" },
      () => current,
    );
    current = false;
    finishPermission();

    await expect(pending).resolves.toEqual({ started: false, stale: true });
    expect(audio.stopMicrophone).toHaveBeenCalledWith({ endTurn: false });
  });

  it("uses freshly negotiated audio and never primes playback for text-only sessions", () => {
    const utilities = loadDashboardUtilities();
    const source = dashboardSource();
    const staleStatusInput = { enabled: true, mimeType: "audio/pcm;rate=16000" };
    const negotiated = { session: { realtime: { audio: { input: { enabled: false } } } } };

    const inputAudio = utilities.negotiatedInputAudio(negotiated, staleStatusInput);
    expect(inputAudio).toMatchObject({ enabled: false });
    expect(utilities.supportsBrowserMicrophone(inputAudio)).toBe(false);
    expect(utilities.negotiatedInputAudio({}, staleStatusInput)).toMatchObject(staleStatusInput);
    expect(source).toContain("if (!supportsBrowserPlayback(outputAudio)) return audio;");
  });

  it("turns gateway failures into exact setup and repair commands", () => {
    const utilities = loadDashboardUtilities();

    expect(utilities.gatewayPresentation({ configured: false }).detail).toContain("hermes-live setup");
    expect(utilities.gatewayPresentation({ reachable: false }).detail).toContain("hermes-live service status");
    expect(utilities.gatewayPresentation({ reachable: true, ready: false, error: "wrong_gateway_service" }).detail)
      .toContain("hermes-live setup");
    expect(utilities.gatewayPresentation({ ready: false, error: "Hermes is offline." }).detail)
      .toBe("Hermes is offline. Run hermes-live doctor for the exact fix.");
  });

  it("does not offer a connection until the gateway is actually ready", () => {
    const utilities = loadDashboardUtilities();

    expect(utilities.connectControlPresentation({ loading: true }, false, "", "idle"))
      .toEqual({ disabled: true, label: "Checking gateway…" });
    expect(utilities.connectControlPresentation({ ready: false }, false, "", "idle"))
      .toEqual({ disabled: true, label: "Gateway not ready" });
    expect(utilities.connectControlPresentation({ ready: true }, false, "", "idle"))
      .toEqual({ disabled: false, label: "Connect Live Voice" });
  });
});

function dashboardSource(): string {
  return readFileSync(new URL("dist/index.js", dashboardUrl), "utf8");
}

function dashboardDocument() {
  return {
    baseURI: "http://127.0.0.1:9119/",
    currentScript: {
      src: "http://127.0.0.1:9119/api/dashboard-plugins/hermes-live/dist/index.js",
    },
    querySelector: vi.fn(),
  };
}

function task(
  taskId: string,
  state: string,
  sequence: number,
  updatedAt: number,
  extra: Record<string, unknown> = {},
) {
  return { taskId, title: taskId, state, sequence, updatedAt, ...extra };
}

function loadDashboardUtilities(): Record<string, (...args: any[]) => any> {
  const source = dashboardSource().replace(
    "  function LiveVoicePage() {",
    `  window.__HERMES_LIVE_TEST_UTILITIES__ = {
      connectedSessionGuidance,
      connectedSessionNotice,
      connectionClosedNotice,
      connectControlPresentation,
      disconnectSession,
      gatewayPresentation,
      isTaskActive,
      microphoneActiveGuidance,
      negotiatedInputAudio,
      supportsBrowserPlayback,
      supportsBrowserMicrophone,
      startMicrophoneAfterConnect,
      scrollTranscriptToLatest,
      taskDetail,
      taskInboxItems,
      taskInboxSummary,
      taskProgressText,
      taskStatePresentation,
    };

  function LiveVoicePage() {`,
  );
  const window: Record<string, any> = {
    location: { href: "http://127.0.0.1:9119/live-voice" },
  };

  vm.runInNewContext(source, { document: dashboardDocument(), Error, Promise, URL, window }, {
    filename: "plugins/hermes-live/dashboard/dist/index.js",
  });

  return window.__HERMES_LIVE_TEST_UTILITIES__;
}
